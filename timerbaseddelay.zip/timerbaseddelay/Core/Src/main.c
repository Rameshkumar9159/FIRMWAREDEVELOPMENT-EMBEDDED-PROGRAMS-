#include "stm32f4xx.h"
#include "systick.h"

int main(void) {
	   systick();
}
