#include <led_blink.h>

int main(void) {

    led_blink();

}
